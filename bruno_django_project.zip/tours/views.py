from django.shortcuts import render
from django.shortcuts import get_object_or_404

from tours.models import Tour
from tours.services import get_full_schedule, get_all_active_tours


def get_all_tours(request):
    if request.method == 'GET':
        tours = get_all_active_tours()
        # Вернуть html со всеми турами
        return render(request, 'tours/index.html', context=dict(tours=tours))


def get_tour_detail(request, tour_id):
    print(f">>>{tour_id=}")
    tour = get_object_or_404(Tour, id=tour_id)
    # free_slots = ','.join([f"'{slot}'" for slot in tour.slots_str.split(',')])
    # freeSlots - Полуить из Бд связанные с туром Schedule и привести его к формату котррый нужен на фронте (в шаблоне)
    # bookPageUrl - Добавить отдельную view  обработкой бронирования
    return render(request, 'tours/tour_detail.html', context=dict(tour=tour))
